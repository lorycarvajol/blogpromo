<footer>
    <?php wp_footer(); ?>
    <p>copyright 2021 Pierre et Lory - tout droit réservés</p>
</footer>
</body>
</html>