<?php
get_header();
?>

<p>
<img src="<?php echo get_template_directory_uri(); ?>./assets/'404'.png"  width="100%" height="100%"/>
</p>
<?php
get_footer();
